package bot;


import tools.*;
import java.io.*;
import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This bot is to manage the registration of the user with the command '/registration'.
 * The user will be asked to provide a registration code. If the registration code is
 * correct, the user will be registered to the system.
 * <p>
 * The user cannot register again if the user has already registered (One discord ID
 * to one student ID).
 * <p>
 * We assume the registration code will be sent to students via email in advanced.
 * The registration information is given in a file (please check users.csv)
 * <p>
 * The file format of users.csv is as follows:
 * <p>
 * Each row may have three columns or five columns.
 * <p>
 * Three Columns, e.g.:
 * 20100001,g8xa9s,Bruce Lee
 * That represents the student ID is 20100001, the registration code is g8xa9s, and the name is Bruce Lee.
 * <p>
 * Five Columns, e.g.:
 * 20100002,-,Chan Tai Man,1004553330619580487,Kevin Wang
 * That represents the
 * student ID is 20100002,
 * the registration code is empty (registered already),
 * the student name is Chan Tai Man,
 * the discord ID is 1004553330619580487, and
 * the discord name is Kevin Wang.
 */
public class UserManagementBot extends CommandBot {
    //Add your data member here
    private List<User> lstStudentObject = new ArrayList();
    private String fileName = "";
    private Integer intLength = 3;
    String strWarnNoFile = "Unable to locate the file.";
    String strReplyRegCode = "Registration code : ";
    User userObject;

    //Constructor
    public UserManagementBot(String filename) {
        lstStudentObject = new ArrayList<>();

        //TODO
        File inputFile = new File(filename);

        if (!inputFile.exists()) {
            System.out.println("The file " + filename + " is not found.");
        }
        try {
            Scanner in = new Scanner(inputFile);

            while (in.hasNextLine()) {
                User user;

                String str = in.nextLine();

                String[] strList = str.split(",");

                if (strList.length == 3) {
                    user = new User(strList[0], strList[1]);
                } else {
                    user = new User();

                    user.setStudentID(strList[0]);

                    user.setStudentName(strList[2]);

                    user.setID(strList[3]);

                    user.setUsername(strList[4]);
                }

                lstStudentObject.add(user);

                System.out.println();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        addOption("regcode" , "Your registration code" ,true);
    }


    /**
     * Written for you. No need to change it
     */
    @Override
    public String getCommand() {
        return "registration";
    }

    /**
     * Written for you. No need to change it
     */
    @Override
    public String getCommandHelp() {
        return "Registers the user";
    }


    /**
     * to check if a user has been registered
     */
    boolean isRegistered(String id) {
        //TODO

        for(int x = 0 ; x < lstStudentObject.size() ; x++){
            if(lstStudentObject.get(x).getID() != null || lstStudentObject.get(x).getID()!= "") {
                if (lstStudentObject.get(x).getID().equals(id))
                    return true;
            }
        }

        return false;
    }


    /**
     * To respond to the command '/registration'.
     * <p>
     * If the user has already registered, return "You are already registered!"
     * If the registration code is correct, register the user and return "You are registered!".
     * If the registration code is incorrect, return "Invalid registration code!"
     * <p>
     * To avoid data lost, remember to save the data to the file after each user's registration.
     */
    @Override
    public String respond(Command command) {
        //TODO

        System.out.println("Registration Bot received a slash command 'registration' from user: " + command.getName());

        for (int i = 0; i < lstStudentObject.size(); i++) {
            //User aUser = getStudent(command.getSenderID());

            if (lstStudentObject.get(i).getUsername() == null) {
                if (command.getOption("regcode").equals(lstStudentObject.get(i).getRegistrationCode())) {
                    lstStudentObject.get(i).setID(command.getSenderID());
                    lstStudentObject.get(i).setUsername(command.getName());
                    //saveWriting();
                    return "You are registered!";
                }
            }

            if (command.getSenderID().equals(lstStudentObject.get(i).getID())) {
                if (!(command.getOption("regcode").equals(lstStudentObject.get(i).getRegistrationCode()))) {
                    return "Invalid registration code";
                }

                return "You are already registered!";
            }
        }




        return "Invalid registration code";
    }

    private void saveWriting() {
        String strWarnWrite = "Write file: ";
        try {
            PrintWriter prtWriter = new PrintWriter(fileName);
            String strAns = "";
            for(int x= 0 ;x < lstStudentObject.size(); x++){
                User userObject = lstStudentObject.get(x);
                if (userObject.getID() != null && userObject.getID() != "") {
                    strAns = "Student ID: " +userObject.getStudentID() + ", - ," + userObject.getStudentName() + "," + userObject.getID() + "," + userObject.getUsername() + "\n";

                    prtWriter.printf(strAns);
                } else {
                    strAns = userObject.getStudentID() + "," + userObject.getRegistrationCode() + "," + userObject.getStudentName()+"\n";

                    prtWriter.printf(strAns);
                }
            }
            prtWriter.close();
        } catch (Exception g) {
            System.out.println(strWarnWrite);
        }
    }

    /**
     * return the student ID of the user with the given discord ID
     * <p>
     * throws an IDNotFoundException if the discord ID cannot be found
     */
    public String getStudentID(String id) throws IDNotFoundException {
        //TODO

        return getStudent(id).getStudentID();
    }

    /**
     * return the user object with the given discord ID
     * <p>
     * throws an IDNotFoundException if the discord ID cannot be found
     */
    public User getStudent(String id) throws IDNotFoundException {
        //TODO
        for(int x= 0 ;x < lstStudentObject.size(); x++){
            User userObject = lstStudentObject.get(x);

            if (userObject != null) {
                if (userObject.getID() != null && userObject.getID() != ""){
                    if(userObject.getID().equals(id))
                        return userObject;
                }
            }
        }

        throw new IDNotFoundException("ID [" + id + "] not found!");

    }


    /**
     * Output how many number of users have registered.
     */
    @Override
    public void actionPerform() {

        int counter = 0;
        String strReplyRegBot = "Reg Bot : ";
        String strReplyNumberOfRegBot = "Reg Bot : ";
        for(int x= 0 ;x < lstStudentObject.size(); x++){
            User userObject = lstStudentObject.get(x);
            if (userObject.getID() != null && userObject.getID() != ""){
                counter++;
            }
        }
        strReplyNumberOfRegBot = strReplyRegBot + counter + " out of total number of " + lstStudentObject.size();
        System.out.println(strReplyNumberOfRegBot);
    }
}
