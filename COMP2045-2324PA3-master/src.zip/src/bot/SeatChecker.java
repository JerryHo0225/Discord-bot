package bot;

import tools.*;

import java.util.Arrays;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * This bot will check the seat of a quiz or practical test for a student.
 *
 * This message bot will only work in private message. 
 * The user should first type "seat" to start the conversation. 
 * The bot will then ask for the student ID. The bot is expecting
 * a 8-digit number as the student ID and ignore any other message.
 * After received the 8-digit number in a private message, the bot 
 * will check the seat of the student and return the seat number.
 *
 * The bot allows the user to check seat for other students or check
 * the seat even if the user did not register to UserManagementBot before.
 *
 * We will assume the seat will never change during the execution of the 
 * program. Any change of seat will require the program to restart.
 */
public class SeatChecker implements MessageListener {
    //Status: Done

    static final String DEFAULT_FILE = "seat.csv";

    //TODO: Add your private data member here
    List<String> lstStudentId = new ArrayList<>();
    List<TextPair> lstSeat = new ArrayList<>();

    //TODO: Add your methods here
    public SeatChecker() {
        this(DEFAULT_FILE);
    }

    public SeatChecker(String filename) {
        try {
            Scanner scaUserInput = new Scanner(new File(DEFAULT_FILE));
            String strWarnLineInvalid = "The invalid line : ";
            String strWarnFileInvalid = "The invalid file name : ";
            while (scaUserInput.hasNextLine()) {
                String[] arrUserInput = scaUserInput.nextLine().split(",");
                if (arrUserInput.length != 2)
                    System.out.println(strWarnLineInvalid + scaUserInput.nextLine());
                else
                    lstSeat.add(new TextPair(arrUserInput[0], arrUserInput[1]));
            }
            scaUserInput.close();

        } catch (FileNotFoundException e) {
            System.out.println("invalid file name : " + filename);
        }
    }

    private boolean isStudentIDValid(String strStudentId) {
        Integer intStudentId;
        int intLen = 8;

        try {
            intStudentId = Integer.parseInt(strStudentId);
        } catch (NumberFormatException nfe) {
            return false;
        }

        return strStudentId.length() == intLen;
    }

    @Override
    public String onMessageReceived(Message msg) {
        String strWarnUnableToFindSeat = "Unable to locate the seat.";
        String strWarnPrivateMsgOnly = "For Private Message only.";
        String strReplySeatNumber = "The seat number : ";
        String strReplyInputID = "Please input your ID : ";
        String strSeatInput = "seat";
        String strSeatNum = "";

        if (lstStudentId.contains(msg.getSenderID())) {
            if (msg.isPrivate() == false || isStudentIDValid(msg.getContent()) == false)
                return null;

            else {
                strSeatNum = seatNum(msg.getContent());
                lstStudentId.remove(msg.getSenderID());
                if (strSeatNum == null || strSeatNum == "")
                    return (strWarnUnableToFindSeat);
                else
                    return (strReplySeatNumber + strSeatNum);
            }
        } else if (msg.getContent().equals(strSeatInput)) {
            if (msg.isPrivate() == false)
                return strWarnPrivateMsgOnly;
            else {
                lstStudentId.add(msg.getSenderID());
                return strReplyInputID;
            }
        } else
            return null;
    }

    private String seatNum(String strInput) {
        for (int x = 0; x < lstSeat.size(); x++) {
            TextPair pair = lstSeat.get(x);
            if (pair != null) {
                if (pair.getName().equals(strInput)) {
                    return pair.getValue();
                }
            }


        }
        return null;
    }
}
